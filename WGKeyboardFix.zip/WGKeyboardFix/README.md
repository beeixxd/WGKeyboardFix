# WGKeyboardFix

修复 Whitegram (`ph.telegra.Telegraph.wge`, 从上传的 IPA 里读到的 Bundle ID)
在 FaceID / 密码解锁 App 内锁屏后，键盘卡住收不回去 / 输入框错误聚焦
在已经消失的密码输入框上的问题。

## 我是怎么定位到这个原因的

对你上传的 `Whitegram_Beta_2_5__12_8_.ipa` 做了静态分析(没有做完整反汇编，
下面结论基于符号表+已知的 Telegram/Display 框架架构，不是100%动态验证过):

1. `Payload/Telegram.app/Frameworks/TelegramUIFramework.framework` 是没加密的
   (没有 `LC_ENCRYPTION_INFO_64` crypt id，可以直接读符号表)。
2. 密码解锁页面对应的类是 Swift 类 `PasscodeUI.PasscodeEntryController`，
   它的 ObjC 可见名是 `_TtC10PasscodeUI23PasscodeEntryController`
   (说明这个类继承链上有 NSObject/UIViewController，可以用 ObjC runtime hook)。
3. 密码输入框对应的节点类 `PasscodeUI.PasscodeInputFieldNode` 只导出了
   `activate()` (对应 `becomeFirstResponder`)，**整个二进制里找不到任何
   deactivate / resignFirstResponder / endEditing 相关的导出符号**，
   `PasscodeEntryController` 自己也没有重写 `viewDidDisappear:`。
4. 结论: 密码框大概率没有一条可靠的路径，在它被挪出屏幕(而不是走标准的
   `dismiss(animated:)`)时主动交还第一响应者。跟你自己画的那张
   "FaceID Success → dismiss → 没有 endEditing/resignFirstResponder →
   deinit → KeyboardHide 没人处理" 的流程图基本吻合，只是具体"漏掉的那一步"
   更可能是密码输入框节点本身缺一个收尾方法，而不是某个通知丢了。

5. 另外确认了这个 IPA 的插件注入方式: `Payload/Telegram.app/` 根目录下已经有
   `SideloadFix27.dylib` / `Sideloadbypass1.dylib` / `Sideloadbypass2.dylib` /
   `sideloadKeychainFix.dylib` / `sideloadFixerLol.dylib` 这几个 dylib，
   都是通过在主程序 `Telegram` 的 Mach-O 里加 `LC_LOAD_WEAK_DYLIB
   @executable_path/xxx.dylib` 这种方式直接注入的 (不依赖越狱 Substrate，
   符号表里也没有链接 libsubstrate/libhooker)。所以这个修复也做成同样形式的
   独立 dylib，而不是系统级越狱 tweak。

## 修复策略

不去赌具体是哪一行代码漏掉了(私有 Swift 方法，没条件反编译到指令级confirm)，
而是用一个"防御性但精准触发"的方案:

1. Hook `_TtC10PasscodeUI23PasscodeEntryController` 的 `-dealloc`
   (Swift NSObject 子类的 `deinit` 保证会走到这里，是最稳、跨版本兼容性
   最好的收尾时机) → 在这里强制交还第一响应者、收起键盘。
2. Hook 它的 `viewDidAppear:`，只是用来打一个"密码页确实出现过"的标记，
   避免第 3 步误伤用户平时在聊天里正常打字的场景。
3. 在 `UIApplicationDidBecomeActiveNotification` 里做一次兜底强制 resign
   (只在标记为真时触发)，覆盖 `dealloc` 因为某些 retain 被延迟触发的情况。
4. 强制 resign 用的是 `[[UIApplication sharedApplication]
   sendAction:@selector(resignFirstResponder) to:nil from:nil forEvent:nil]`
   这个公开 API 技巧: 让 UIKit 自己去找当前真正的第一响应者，不需要我们
   知道它具体挂在哪个 window/控件上，所以即使密码框所在的 window 已经隐藏，
   依然能生效。

## 文件说明

- `WGKeyboardFix.m` — 纯 Objective-C 实现，只用 `<objc/runtime.h>`，
  **不依赖任何 CydiaSubstrate / libhooker / ElleKit**，跟包里已有的
  `sideloadFixerLol.dylib` 是同一种"直接注入单个IPA、无需越狱"的风格。
  **这是推荐编译的版本。**
- `Tweak.xm` — 功能完全一样的 Logos 语法版本，如果你的 Theos 工作流更习惯
  `%hook` 写法可以用这个，二选一编译，不要两个一起编译。
- `Makefile` — Theos 工程文件，默认编译 `WGKeyboardFix.m`。

## ⚠️ 重要: 我没能在这里帮你编译出成品 dylib

我这边的沙箱环境没有 clang / iOS SDK / Theos 工具链（我检查过，确实都不在），
所以**没办法在这里实际编译出一个能跑的 arm64 dylib**。给你一个"看起来编译好"
但其实是编不出来的假文件没有意义，所以这个压缩包里给的是**完整可编译的源码**，
不是二进制。你之前做过 Theos 项目 (AutoFLEX 中文化、Douyin 弹簧动画修复等)，
这套源码是照着同样的 Theos 工程结构写的，应该可以直接在你自己的环境编译。

## 编译步骤 (在你自己的 macOS + Theos 环境)

```bash
# 把这个文件夹放到你的 theos 项目目录下，或者单独一个 Theos 工程都行
export THEOS=/opt/theos   # 换成你自己的 THEOS 路径
cd WGKeyboardFix
make clean
make package FINALPACKAGE=1
```

编译完成后产物在 `.theos/obj/debug/` (或 `make package` 后在
`packages/` 目录里，如果不需要 .deb 包装可以直接用 `.theos/obj/...` 下面
那个 `WGKeyboardFix.dylib`)。

如果你不用 Theos，纯手动 clang 也可以（需要有 Xcode 命令行工具）:

```bash
clang -dynamiclib -arch arm64 -miphoneos-version-min=13.0 \
  -isysroot $(xcrun --sdk iphoneos --show-sdk-path) \
  -framework UIKit -framework Foundation \
  -o WGKeyboardFix.dylib WGKeyboardFix.m
ldid -S WGKeyboardFix.dylib
```

## 注入到 IPA 里

跟包里已有的那几个 sideload dylib 完全一样的做法:

1. 把编译好的 `WGKeyboardFix.dylib` 放进
   `Payload/Telegram.app/WGKeyboardFix.dylib` (跟主程序同一目录，不是
   Frameworks 子目录)。
2. 用 `insert_dylib` / `optool` 之类的工具给主程序 `Telegram` 加一条:
   ```
   insert_dylib --weak --inplace \
     @executable_path/WGKeyboardFix.dylib \
     Payload/Telegram.app/Telegram
   ```
   (加 `--weak` 是为了跟包里已有的其它 dylib 保持一致，即使这个 dylib
   加载失败也不会导致整个 App 直接闪退)
3. 重新打包成 IPA、用你自己的证书重新签名整个 App（包括这个新 dylib 本身
   也要签），然后安装。

如果你用的是 TrollFools 这类图形化注入工具，直接把
`WGKeyboardFix.dylib` 拖进去让它帮你完成插入+重签名即可，原理是一样的。

## 测试方法

1. 打开应用锁 (FaceID 或密码)。
2. 把 App 切到后台，锁屏或等它触发应用内锁定。
3. 用 FaceID 解锁回到 App。
4. 正常情况下应该不再出现: 键盘卡住收不回去 / 输入框莫名展开到屏幕中间但
   键盘位置空白 / 主页留有键盘阴影区域 这几种现象。
5. 如果还有问题，大概率说明具体的私有方法名跟这次分析的不完全一样(比如
   Whitegram 后续版本 Telegram 内核升级后重新命名了)，需要针对新版本
   binary 重新跑一遍符号分析，这个我可以帮你继续排查。
